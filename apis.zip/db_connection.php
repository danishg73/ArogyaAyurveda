<?php

function OpenCon()
 {
	$servername = "localhost";
	$username = "u970414201_agadayurveda";
	$password = "tRWFmN3@";
	$dbname = "u970414201_agadayurveda";
	 // Create connection
	$conn = new mysqli($servername, $username, $password, $dbname) or die("Connect failed: %s\n". $conn -> error);
     
	return $conn;
 }
 
function CloseCon($conn)
 {
	$conn -> close();
 }
   
?>