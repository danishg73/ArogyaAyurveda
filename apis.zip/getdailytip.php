<?php 
 include 'db_connection.php';
 $conn = OpenCon();
   
$password ="as";  

 
 
if($password==Null)
{
echo "Password cannot be empty.";
}
else{ 
    date_default_timezone_set("Asia/Calcutta");
    $date = date("Y-m-d");
    echo $date;

    $sql="SELECT * FROM dailytip where date ='$date'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) 
    {
    // output data of each row
         while($row = $result->fetch_assoc()) 
         { 
 
            $data[] = array(
                
                 "id"=>$row['id'], 
                 "title"=> $row['title'],  
                 "description"=>$row['description'],  
                 "date"=>$row['date'],    
                 );
             
         }
    $myJSON = json_encode($data);
    echo $myJSON;
    }
    else 
    {
    echo "No details found";
    }
} // else end

CloseCon($conn);
 
 
 
?> 