<?php 
 include 'db_connection.php';
 $conn = OpenCon();
      
 $title = $_POST['title'];
 $description = $_POST['description']; 
 $category = $_POST['category'];
 $subcategory = $_POST['subcategory'];
//$title = "disease";
//$description = "corona";
//$category ="ss";
//$subcategory ="sas";
if($title==Null)
    {
        echo "title cannot be empty.";
    }
else if($description==Null)
    {
        echo "description cannot be empty.";
    }
else
    {
        $insert="INSERT INTO details( title, description, category,subcategory )         VALUES ('$title','$description','$category','$subcategory')"; 
                     
                    if ($conn->query($insert) === TRUE) 
                    {
                        echo "Added Successfully";
                    }
                    else     
                    {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }
                    
    } 

CloseCon($conn);
 
 
 
?> 