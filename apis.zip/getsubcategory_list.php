<?php 
 include 'db_connection.php';
 $conn = OpenCon();
      
 
//$category = "disease";
$subcategory = "corona";
 
 
 if($subcategory==Null)
{
echo "subcategory cannot be empty.";
}
else{ 

    $sql="SELECT * FROM subcategory";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) 
    {
    // output data of each row
         while($row = $result->fetch_assoc()) 
         { 
 
            $data[] = array(
                
                 "id"=>$row['id'],    
                 "category"=>$row['category'],  
                 "subcategory"=>$row['subcategory'],  
                 );
             
         }
    $myJSON = json_encode($data);
    echo $myJSON;
    }
    else 
    {
    echo "No details found";
    }
} // else end

CloseCon($conn);
 
 
 
?> 