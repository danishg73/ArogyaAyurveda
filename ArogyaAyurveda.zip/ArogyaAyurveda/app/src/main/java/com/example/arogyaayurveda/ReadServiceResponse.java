package com.example.arogyaayurveda;

public interface ReadServiceResponse {
    void processFinish(String output);
}

