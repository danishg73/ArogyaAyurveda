package com.example.arogyaayurveda;

public class category_list {
    public String subcategory;
    public String category_id;
    public String parentcategory;
}
