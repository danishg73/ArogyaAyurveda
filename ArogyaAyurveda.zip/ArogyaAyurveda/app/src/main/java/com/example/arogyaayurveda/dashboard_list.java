package com.example.arogyaayurveda;

public class dashboard_list {
    public String title;
    public String description;
    public String id;
    public String timestamp;
    public String category;
    public String subcategory;
    public String fav;

}
