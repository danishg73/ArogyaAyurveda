package com.example.adminpannelagadayurveda;

public interface ReadServiceResponse {
    void processFinish(String output);
}

